# hello world of 2 way binding

In the [hello world example](https://www.notion.so/hello-world-example-f301739ea9f743959fd6f741d14d3a47) we saw that we can bind a variable from the store to the component with asr-bind. Now let's see if we can update the variable in one component and see it being updated in the other. For this we'll extend our hello world example.

For a quick overview go to the sandbox environment to follow along:

[](https://codesandbox.io/s/manual-hello-world-of-2-way-binding-lcjpx)

# binding a model

To make the store variable `message` we used above 2-way-bound, we need to tell the component that the variable is a model. (Meaning it implements both a setter and a getter).

So let's update our App.vue file:

    // src/App.vue
    
    <template>
      <div id="app">
        <example-message asr-bind="message"/>
        <text-input asr-bind="message IS v-model"/>
      </div>
    </template>
    
    <script>
    import ExampleMessage from "./components/ExampleMessage";
    import TextInput from "./components/TextInput";
    
    export default {
      name: "App",
      components: {
        ExampleMessage,
    		TextInput
      }
    };
    </script>

Notice that we also use the property `asr-bind` but we tell that the variable message is a model: 

`asr-bind="message IS v-model"` or simpler:

`asr-bind="message IS model"`

## the Text Input component

Now that we have our variable message availlable as a model we can simply assign it to an input's v-model property:

    // src/components/TextInput.vue
    
    <template>
      <input v-model="message">
    </template>

and that's all.

If you now change the contents of the message in the input field that is rendered you'll see that also the message in the `example-message` component is updated. cool right 😎

But as I already stated VUEX-ASR was created with the intention of making building large-scale applications easier, so let's jump to the next subject of Aliasing where we can see how we could use aliasing to make reusability of components a breeze.